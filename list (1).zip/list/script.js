document.getElementById('loginForm').addEventListener('submit', function(event) {
   event.preventDefault();
   
   // Get the input values
   var username = document.getElementById('username').value;
   var password = document.getElementById('password').value;

   // Basic validation (replace with actual logic as needed)
   if (username === "user" && password === "pass123") {
       alert("Login successful!");
   } else {
       document.getElementById('error-message').textContent = "Invalid username or password!";
   }
});
